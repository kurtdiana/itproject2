<?php /* C:\xampp\htdocs\lsapp\resources\views/pages/addPatient.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Perez - Magabo Dental Clinic - Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- CSS -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
    <!-- scripts -->
    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui-1.10.4.min.js"></script>
    <script src="js/jquery-1.8.3.min.js"></script>
    <script  src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js"> </script>
    <script src="js/scripts.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/demo/datatables-demo.js"></script>
  </head>
  <body id="page-top">
    <div id="wrapper">
      <section id="container" class="">
        <header class="header dark-bg">
          <div class="toggle-nav">
            <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
          </div>
          <a href="index.html" class="logo">PEREZ-MAGABO <span class="lite">CLINIC</span></a>
          <div class="nav search-row" id="top_menu">
            <ul class="nav top-menu">
              
            </ul>
          </div>
          <div class="top-nav notification-row">
            <ul class="nav pull-right top-menu"></ul>
          </div>
        </header>
      <aside>
        <div id="sidebar" class="nav-collapse ">
          <ul class="sidebar-menu">
            <li class="active">
              <a class="" href="index.html">
                <i class="icon_house_alt"></i>
                <span>Dashboard</span>
              </a>
            </li>
            <li class="sub-menu">
              <a href="patient.html" class="">
                <i class="icon_documents_alt"></i>
                <span>Patient</span>
              </a>
            </li>
            <li class="sub-menu">
              <a class="patient.html">
                <i class="icon_document_alt"></i>
                <span>Records</span>
                <span class="menu-arrow arrow_carrot-right"></span>
              </a>
              <ul class="sub">
                <li><a class="" href="patientrec.html">Patient's Chart</a></li>
                <li><a class="" href="salesrec.html">Sales Records</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </aside>
              <section id="main-content">
        <section class="wrapper">
        <div class="nav search-row" id="top_menu">
          <ul class="nav top-menu">
          </ul>
        </div>
        <br>

                </li>
              </ul>
            </nav>
          <div class="container-fluid">
              <h1 class="h3 mb-2 text-gray-800">Add New Patient</h1>
              <!--<div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(Session::has('alert-' . $msg)): ?>
                      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?></p>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>-->
              <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Please enter the needed information of the patient.</h6>
                  </div>
                  <div class="card-body">
                      <form action="/addpatient" method="POST">
                        <?php echo csrf_field(); ?>
                          <div class="form-group row">
                            <div class="col-sm-6 mb-3 mb-sm-0">
                              <input type="text" class="form-control form-control-user" id="exampleFirstName" placeholder="First Name" name="first_name">
                            </div>

                            <div class="col-sm-6 mb-3 mb-sm-0">
                              <input type="text" class="form-control form-control-user" id="exampleLastName" placeholder="Last Name" name='last_name'>
                            </div>

                            <select class="btn btn-primary dropdown-toggle" name='civilstats'>
                              <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Select Civil Status
                              </button>
                                <option value='Single'>Single</option>
                                <option value='Married'>Married</option>
                                <option value='Widow'>Widow</option>
                            </select>

                            <select class="btn btn-primary dropdown-toggle" name='sex'>
                              <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Select Gender
                              </button>
                                <option value='Male'>Male</option>
                                <option value='Female'>Female</option>
                            </select>

                          <div class="form-group">
                            <input type="text" class="form-control form-control-user" id="exampleAddress" placeholder="Present Address" name='pat_address'>
                          </div>
                          <div class="form-group">
                            <input type="text" class="form-control form-control-user" id="exampleAddress" placeholder="Permanent Address" name='pat_paddress'>
                          </div>
                          <div class="form-group row">
                            <div class="col-sm-6 mb-3 mb-sm-0">
                              <input type="date" class="form-control form-control-user" id="exampleBirthday" placeholder="Birthday" name='birthday'>
                            </div>
                            <div class="col-sm-6">
                              <input type="text" class="form-control form-control-user" id="exampleContactNo" placeholder="Contact No." name='pat_contno'>
                            </div>

                          </div>
                           <div class="col-sm-6">
                              <input type="text" class="form-control form-control-user" id="exampleMedical" placeholder="Case History" name='case_history'>
                            </div>
                            
                            <div class="my-2"></div>
                    <button class="btn btn-success btn-icon-split" type='submit'>
                      <span class="icon text-white-50">
                        <i class="fas fa-check"></i>
                      </span>
                      <span class="text">Confirm Submission</span>
                    
                  </div>
                </div>
          </div>
</form>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <!-- scripts -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
  </body>
</html>