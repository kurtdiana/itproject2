<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Patient;
class PatientAddController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        return view('pages.addPatient');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $insertPatient = new Patient;
        $insertPatient->first_name = $request->input('first_name');
        $insertPatient->last_name = $request->input('last_name');
        $insertPatient->civilstats = $request->input('civilstats');
        $insertPatient->sex = $request->input('sex');
        $insertPatient->pat_address = $request->input('pat_address');
        $insertPatient->pat_paddress = $request->input('pat_paddress');
        $insertPatient->birthday = $request->input('birthday');
        $insertPatient->pat_contno = $request->input('pat_contno');
        $insertPatient->case_history = $request->input('case_history');
        $insertPatient->save();
        return 'successfully added into database.';
        //return back()->with('success','You added new items, follow next step!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
