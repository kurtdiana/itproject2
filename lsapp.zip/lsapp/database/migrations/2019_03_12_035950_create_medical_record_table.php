<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMedicalRecordTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('medical record', function (Blueprint $table) {
            $table->integer('med_recordID')->primary()->unsigned();
            $table->date('date');
            $table->integer('patientID')->unsigned();
            $table->integer('treatmentID')->unsigned();
            $table->foreign('patientID')
            ->references('patientID')
            ->on('patient')
            ->onDelete('cascade');
            $table->foreign('treatmentID')
            ->references('treatmentID')
            ->on('treatment')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('medical record');
    }
}
