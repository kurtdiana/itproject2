<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePatientTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient', function (Blueprint $table) {
            $table->increments('patientID');
            $table->string('first_name');
            $table->string('last_name');
            $table->enum('civilstats',['Single','Married','Widowed']);
            $table->enum('sex',['Male','Female'])->default('Male');
            $table->string('pat_address');
            $table->string('pat_paddress');
            $table->date('birthday');
            $table->string('pat_contno');
            $table->string('case_history');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient');
    }
}
