<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppointmentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appointment', function (Blueprint $table) {
            $table->integer('appointmentID')->primary()->unsigned();
            $table->date('appointmentDate');
            $table->string('appointment_timeLength');
            $table->enum('appointment_status',['Pending','Done','Cancelled','Moved'])->default('Pending');
            $table->integer('patientID')->unsigned();
            $table->integer('empID')->unsigned();
            $table->integer('treatmentID')->unsigned();
            $table->foreign('patientID')
            ->references('patientID')
            ->on('patient')
            ->onDelete('cascade');
            $table->foreign('empID')
            ->references('empID')
            ->on('employee')
            ->onDelete('cascade');
            $table->foreign('treatmentID')
            ->references('treatmentID')
            ->on('treatment')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appointment');
    }
}
