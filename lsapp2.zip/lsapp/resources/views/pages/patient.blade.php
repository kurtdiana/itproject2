<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Perez-Magabo Dental Clinic </title>

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
  <link rel='stylesheet' href='css/jquery-ui.css'>
    

    <!-- CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/fullcalendar.css">
    <link href="css/widgets.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">   
    <link rel="stylesheet" href="patient.css">
    
          <!-- JavaScripts -->

   
  <!-- JavaScripts -->
        <script src="js/jquery.js"></script>
        <script src="js/jquery-ui-1.10.4.min.js"></script>
        <script src="js/jquery-1.8.3.min.js"></script>
        <script src="js/jquery-ui-1.9.2.custom.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.scrollTo.min.js"></script>
        <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
        <script src="js/scripts.js"></script>
        <script src="js/jquery.slimscroll.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="js/sb-admin-2.min.js"></script>
        <script src="vendor/datatables/jquery.dataTables.min.js"></script>
        <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
        <script src="js/demo/datatables-demo.js"></script>
          


  </head>

  <body>
    @if (session('status'))
            {{ session('status') }}
    @endif
    @guest
        <li class="navbar-item">
            <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
        </li>
        @if (Route::has('register'))
            <li class="navbar-item">
                <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
            </li>
        @endif
    @else
    <section id="container" class="">
    <header class="header dark-bg">
        <div class="toggle-nav">
          <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
        </div>
        <a href="/home" class="logo">PEREZ-MAGABO <span class="lite">CLINIC </span></a>
        <div class="nav search-row" id="top_menu">
          <ul class="nav top-menu">
          </ul>
        </div>
        <div class="top-nav notification-row">
          <ul class="nav pull-right top-menu">
            <nav class="navbar navbar-expand navbar-light bg-transparent topbar mb-4 static-top shadow" style="height: 20px;">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown no-arrow mx-1">
                  <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-bell fa-fw" style="margin-top: 15px;"></i>
                    <!-- Counter - Alerts -->
                    <span class="badge badge-danger badge-counter" style="margin-top: 30px;">3+</span>
                  </a>
                  <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                    <h6 class="dropdown-header">
                      Alerts Center
                    </h6>
                    <a class="dropdown-item d-flex align-items-center" href="#">
                      <div class="mr-3">
                        <div class="icon-circle bg-primary">
                          <i class="fas fa-file-alt text-white"></i>
                        </div>
                      </div>
                      <div>
                        <div class="small text-gray-500">December 12, 2019</div>
                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                      </div>
                    </a>
                    <a class="dropdown-item d-flex align-items-center" href="#">
                      <div class="mr-3">
                        <div class="icon-circle bg-success">
                          <i class="fas fa-donate text-white"></i>
                        </div>
                      </div>
                      <div>
                        <div class="small text-gray-500">December 7, 2019</div>
                        $290.29 has been deposited into your account!
                      </div>
                    </a>
                    <a class="dropdown-item d-flex align-items-center" href="#">
                      <div class="mr-3">
                        <div class="icon-circle bg-warning">
                          <i class="fas fa-exclamation-triangle text-white"></i>
                        </div>
                      </div>
                      <div>
                        <div class="small text-gray-500">December 2, 2019</div>
                        Spending Alert: We've noticed unusually high spending for your account.
                      </div>
                    </a>
                    <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                  </div>
                </li>
               </ul>
              </nav>
              <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                  <span class="profile-ava">
                    <img alt="" src="img/avatar1_small.jpg">
                  </span>
                  {{ Auth::user()->name }}
                </a>
                <ul class="dropdown-menu extended logout">
                  <div class="log-arrow-up"></div>
                  <li class="eborder-top">
                    <!--<a href="profile.html">
                      <i class="icon_profile"></i>
                      View Profile
                    </a>-->
                  </li>
                  <li>
                    <a class="" href="{{ route('logout') }}"
                        onclick="event.preventDefault();
                                      document.getElementById('logout-form').submit();">
                        {{ __('Logout') }}
                    </a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                  </li>
                </ul>
            </li>
          
            </ul>
        </div>
      </header>
      <aside>
        <div id="sidebar" class="nav-collapse ">
          <ul class="sidebar-menu">
            <li class="">
              <a class="" href="/home">
                <i class="icon_house_alt"></i>
                <span>Dashboard</span>
              </a>
            </li>
            <li class="sub-menu">
              <a href="/patient" class="active">
                <i class="icon_documents_alt"></i>
                <span>Patient</span>
              </a>
            </li>
            <li class="sub-menu">
              <a href="" class="">
                <i class="icon_documents_alt"></i>
                <span>Patient's Chart</span>
              </a>
            </li>
             <li class="sub-menu">
              <a href="" class="">
                <i class="icon_documents_alt"></i>
                <span>Sales Records</span>
              </a>
            </li>
          </ul>
        </div>
      </aside>
      <section id="main-content">
      <section class="wrapper">
      <div class="nav search-row" id="top_menu">
        <ul class="nav top-menu">
          
        </ul>
      </div>
<br>
<br>
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
             <a href="/addpatient" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Add New Patient</a>
            </div>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Patient ID</th>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Birthdate</th>
                      <th>Contact No.</th>
                      <th>present Address</th>
                      <th>permanent Address</th>
                      <th>Sex</th>
                    </tr>
                  </thead>
                  <tbody>
                  @foreach ($patients as $patient)
                    <tr>
                      <td>{{$patient->patientID}}</td>
                      <td>{{$patient->first_name}}</td>
                      <td>{{$patient->last_name}}</td>
                      <td>{{$patient->birthday}}</td>
                      <td>{{$patient->pat_contno}}</td>
                      <td>{{$patient->pat_address}}</td>
                      <td>{{$patient->pat_paddress}}</td>
                      <td>{{$patient->sex}}</td>
                    </tr>
                  @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

<!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          

 
          
</body>
@endguest
</html>
