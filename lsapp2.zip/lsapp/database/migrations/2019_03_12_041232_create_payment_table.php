<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment', function (Blueprint $table) {
            $table->integer('payID')->primary();
            $table->timestamp('payDate');
            $table->double('payamnt');
            $table->integer('appointmentID')->unsigned();
            $table->integer('balanceID')->unsigned();
            $table->foreign('appointmentID')
            ->references('appointmentID')
            ->on('appointment')
            ->onDelete('cascade');
            $table->foreign('balanceID')
            ->references('balanceID')
            ->on('balance')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payment');
    }
}
