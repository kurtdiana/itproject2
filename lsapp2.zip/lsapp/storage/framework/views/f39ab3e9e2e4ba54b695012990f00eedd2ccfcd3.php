<?php /* C:\xampp\htdocs\lsapp\resources\views/layouts/index2.blade.php */ ?>
<html>
    <head>
        <title>KURT DIANA</title>
    </head>
    <body>
        <center><font size="30"><b><p>HAHAHAHAHHAHA UNGGOY</p></b></font></center>
        <a href='/home'><center><font size="20"><b><p>testing, click me</p></b></font></center></a>
        
    </body>
</html>