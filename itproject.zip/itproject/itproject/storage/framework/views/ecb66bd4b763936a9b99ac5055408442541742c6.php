<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Tables</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">

        

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
                <a class="logo" href="index">PEREZ-MAGABO CLINIC</a>
                <div class="menu-sidebar__content js-scrollbar1">
                    <nav class="navbar-sidebar">
                        <ul class="list-unstyled navbar__list">
                            <li>
                                <a class="js-arrow" href="index">
                                    <i class="fas fa-calendar"></i>Schedule</a>
                            
                                <a href="patient">
                                    <i class="fas fa-user"></i>Patient</a>
                            </li>
                            <li>
                                <a href="patientrecords">
                                    <i class="fas fa-folder"></i>Patient Records</a>
                            </li>
                            <li><li class="active has-sub">
                                <a href="sales">
                                    <i class="fas fa-briefcase"></i>Sales Report</a>
                            </li>

                        </ul>
                    </nav>
                </div>
            </aside>
            <!-- END MENU SIDEBAR-->
    
            <!-- PAGE CONTAINER-->
            <div class="page-container">
                <!-- HEADER DESKTOP-->
                <header class="header-desktop">
                    <div class="section__content section__content--p30">
                        <div class="container-fluid">
                            <div class="header-wrap">
                                
                                
                                    <div class="noti-wrap">
                                        <div class="noti__item js-item-menu">
                                            <i class="zmdi zmdi-notifications"></i>
                                            <span class="quantity">3</span>
                                            <div class="notifi-dropdown js-dropdown">
                                                <div class="notifi__title">
                                                    <p>You have 3 Notifications</p>
                                                </div>
                                                <div class="notifi__item">
                                                    <div class="bg-c1 img-cir img-40">
                                                        <i class="zmdi zmdi-email-open"></i>
                                                    </div>
                                                    <div class="content">
                                                        <p>You got a email notification</p>
                                                        <span class="date">April 12, 2018 06:50</span>
                                                    </div>
                                                </div>
                                                <div class="notifi__item">
                                                    <div class="bg-c2 img-cir img-40">
                                                        <i class="zmdi zmdi-account-box"></i>
                                                    </div>
                                                    <div class="content">
                                                        <p>Your account has been blocked</p>
                                                        <span class="date">April 12, 2018 06:50</span>
                                                    </div>
                                                </div>
                                                <div class="notifi__item">
                                                    <div class="bg-c3 img-cir img-40">
                                                        <i class="zmdi zmdi-file-text"></i>
                                                    </div>
                                                    <div class="content">
                                                        <p>You got a new file</p>
                                                        <span class="date">April 12, 2018 06:50</span>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="account-wrap">
                                        <div class="account-item clearfix js-item-menu">
                                            <div class="content">
                                                <a class="js-acc-btn" href="#">john doe</a>
                                            </div>
                                            <div class="account-dropdown js-dropdown">
                                                <div class="account-dropdown__footer">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-power"></i>Logout</a>
                                                </div>
                                            </div>
                                        </div>
                                     </div>
                                
                            </div>
                        </div>
                    </div>
                </header>

                <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                            <div class="col-lg-12">
                   <!--Form-->
                                <form class="form-header" action="" method="POST">
                                    <input class="au-input au-input--xl" type="text" name="search" placeholder="(Search Patient) Enter Last Name..." />
                                    <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                    </button>
                                </form><br><br>
<div class="container">
        <h2><center>
        Generate Reports</center></h2>
      </div> 
        <ul class="pagination">
          <li><li class="active"><a href="genreport">Daily</a></li>&nbsp; 
          <li><a href="monthly">Monthly</a></li>&nbsp; 
          <li><a href="yearly">Yearly</a></li>&nbsp; 
        </ul>

        <select> 
          <option value="January">January</option>
          <option value="February">February</option>
          <option value="March">March</option>
          <option value="April">April</option>
          <option value="May">May</option>
          <option value="June">June</option>
          <option value="July">July</option>
          <option value="August">August</option>
          <option value="September">September</option>
          <option value="October">October</option>
          <option value="November">November</option>
          <option value="December">December</option>
        </select>


        <select>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
          <option value="31">31</option>
        </select>

        <select>
          <option value="2018">2018</option>
          <option value="2017">2017</option>
          <option value="2016">2016</option>
          <option value="2015">2015</option>
        </select>
      </div>
               
                            <br>
                                <div class="table-responsive table--no-card m-b-30">

                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Sales </th>
                                          
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1/1/2019</td>
                                                <td>10,000 PHP</td>
                                          
                                                <td>
                                                      <div class="header-wrap">

                                                
                                    <button onclick="myFunction()"class="btn btn-success btn-sm" data-toggle="modal">Print</button>
                                     <script> function myFunction() { window.print(); } </script>


                                                    </div>
                                                    <tr>
                                                <td>1/1/2019</td>
                                                <td>10,000 PHP</td>
                                          
                                                <td>
                                                      <div class="header-wrap">

                                                
                                    <button onclick="myFunction()"class="btn btn-success btn-sm" data-toggle="modal">Print</button>
                                     <script> function myFunction() { window.print(); } </script>


                                                    </div>
                                                    <tr>
                                                <td>1/1/2019</td>
                                                <td>10,000 PHP</td>
                                          
                                                <td>
                                                      <div class="header-wrap">

                                                
                                    <button onclick="myFunction()"class="btn btn-success btn-sm" data-toggle="modal">Print</button>
                                     <script> function myFunction() { window.print(); } </script>


                                                    </div>
                                                    <tr>
                                                <td>1/1/2019</td>
                                                <td>10,000 PHP</td>
                                          
                                                <td>
                                                      <div class="header-wrap">

                                                
                                    <button onclick="myFunction()"class="btn btn-success btn-sm" data-toggle="modal">Print</button>
                                     <script> function myFunction() { window.print(); } </script>


                                                    </div>
                                                    <tr>
                                                <td>1/1/2019</td>
                                                <td>10,000 PHP</td>
                                          
                                                <td>
                                                      <div class="header-wrap">

                                                
                                    <button onclick="myFunction()"class="btn btn-success btn-sm" data-toggle="modal">Print</button>
                                     <script> function myFunction() { window.print(); } </script>


                                                    </div>
                                                    <tr>
                                                <td>1/1/2019</td>
                                                <td>10,000 PHP</td>
                                          
                                                <td>
                                                      <div class="header-wrap">

                                                
                                    <button onclick="myFunction()"class="btn btn-success btn-sm" data-toggle="modal">Print</button>
                                     <script> function myFunction() { window.print(); } </script>


                                                    </div>
                                                    <tr>
                                                <td>1/1/2019</td>
                                                <td>10,000 PHP</td>
                                          
                                                <td>
                                                    <div class="header-wrap">

                                                
                                    <button onclick="myFunction()"class="btn btn-success btn-sm" data-toggle="modal">Print</button>
                                     <script> function myFunction() { window.print(); } </script>


                                                    </div>
                                                </td>
                                            </tr>

                                           
                                        </tbody>
                                    </table>

 </div>
    

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->

<?php /**PATH C:\wamp64\www\itproject\itproject\resources\views/pages/genreport.blade.php ENDPATH**/ ?>