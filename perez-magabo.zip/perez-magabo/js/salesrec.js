function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
  
 var id=document.getElementById("id_row"+no);
 var name=document.getElementById("name_row"+no);
 var description=document.getElementById("description_row"+no);
 var date=document.getElementById("date_row"+no);
 var time=document.getElementById("time_row"+no);
 var amount=document.getElementById("amount_row"+no);
 var balance=document.getElementById("balance_row"+no);


 var id_data=id.innerHTML;
 var name_data=name.innerHTML;
 var description_data=description.innerHTML;
 var date_data=date.innerHTML;
 var time_data=time.innerHTML;
 var amount_data=amount.innerHTML;
 var balance_data=balance.innerHTML;
  
 id.innerHTML="<input type='text' id='id_text"+no+"' value='"+id_data+"'>";
 name.innerHTML="<input type='text' id='name_text"+no+"' value='"+name_data+"'>";
 description.innerHTML="<input type='text' id='description_text"+no+"' value='"+description_data+"'>";
 date.innerHTML="<input type='text' id='date_text"+no+"' value='"+date_data+"'>";
 time.innerHTML="<input type='text' id='time_text"+no+"' value='"+time_data+"'>";
 amount.innerHTML="<input type='text' id='amount_text"+no+"' value='"+amount_data+"'>";
 balance.innerHTML="<input type='text' id='balance_text"+no+"' value='"+balance_data+"'>";
}

function save_row(no)
{
  var id_val=document.getElementById("id_text"+no).value;
 var name_val=document.getElementById("name_text"+no).value;
 var description_val=document.getElementById("description_text"+no).value;
 var date_val=document.getElementById("date_text"+no).value;
 var time_val=document.getElementById("time_text"+no).value;
 var amount_val=document.getElementById("amount_text"+no).value;
 var balance_val=document.getElementById("balance_text"+no).value;

 document.getElementById("id_row"+no).innerHTML=id_val;
 document.getElementById("name_row"+no).innerHTML=name_val;
 document.getElementById("description_row"+no).innerHTML=description_val;
 document.getElementById("date_row"+no).innerHTML=date_val;
 document.getElementById("time_row"+no).innerHTML=time_val;
 document.getElementById("amount_row"+no).innerHTML=amount_val;
 document.getElementById("balance_row"+no).innerHTML=balance_val;

 document.getElementById("edit_button"+no).style.display="block";
 document.getElementById("save_button"+no).style.display="none";
}


function add_row()
{
 var id_val=document.getElementById("id_text"+no).value;
 var name_val=document.getElementById("name_text"+no).value;
 var description_val=document.getElementById("description_text"+no).value;
 var date_val=document.getElementById("date_text"+no).value;
 var time_val=document.getElementById("time_text"+no).value;
 var amount_val=document.getElementById("amount_text"+no).value;
 var balance_val=document.getElementById("balance_text"+no).value;

 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='name_row"+table_len+"'>"+new_name+"</td><td id='country_row"+table_len+"'>"+new_country+"</td><td id='age_row"+table_len+"'>"+new_age+"</td><td><input type='button' id='edit_button"+table_len+"' value='Edit' class='edit' onclick='edit_row("+table_len+")'> <input type='button' id='save_button"+table_len+"' value='Save' class='save' onclick='save_row("+table_len+")'> <input type='button' value='Delete' class='delete' onclick='delete_row("+table_len+")'></td></tr>";


 document.getElementById("id_row"+no).innerHTML=id_val;
 document.getElementById("name_row"+no).innerHTML=name_val;
 document.getElementById("description_row"+no).innerHTML=description_val;
 document.getElementById("date_row"+no).innerHTML=date_val;
 document.getElementById("time_row"+no).innerHTML=time_val;
 document.getElementById("amount_row"+no).innerHTML=amount_val;
 document.getElementById("balance_row"+no).innerHTML=balance_val;

}
