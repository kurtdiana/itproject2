<?php /* C:\xampp\htdocs\lsapp\resources\views/pages/addAppointment.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Perez-Magabo Dental Clinic </title>

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
  <link rel='stylesheet' href='css/jquery-ui.css'>
    

    <!-- CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/fullcalendar.css">
    <link href="css/widgets.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    
    
          <!-- JavaScripts -->

   
  <!-- JavaScripts -->
        <script src="js/jquery.js"></script>
        <script src="js/jquery-ui-1.10.4.min.js"></script>
        <script src="js/jquery-1.8.3.min.js"></script>
        <script src="js/jquery-ui-1.9.2.custom.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.scrollTo.min.js"></script>
        <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
        <script src="js/scripts.js"></script>
        <script src="js/jquery.slimscroll.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="js/sb-admin-2.min.js"></script>
        <script src="vendor/datatables/jquery.dataTables.min.js"></script>
        <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
        <script src="js/demo/datatables-demo.js"></script>
          
        <style>
            #calendarmargin{
                margin-left: 250px;
            }
            .modal {
                display: none;
                position: fixed;
                margin-top: 80px;
                margin-left: 400px;
                width: 100%;
                overflow: auto;
            }
            
            .modal-content {
                background-color: #fefefe;
                margin: auto;
                padding: 20px;
                border: 1px solid #888;
                width: 80%;
            }

            .close {
                color: #aaaaaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
            }

            .close:hover, .close:focus {
                color: #000;
                text-decoration: none;
                cursor: pointer;
            }
            #buttons{
                margin-left: 150px;
                margin-bottom: 30px;
                margin-top: -10px;
            }
        </style>

  </head>

  <body>
    <section id="container" class="">
    <section id="container" class="">
    <header class="header dark-bg">
        <div class="toggle-nav">
          <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
        </div>
        <a href="/home" class="logo">PEREZ-MAGABO <span class="lite">CLINIC </span></a>
        <div class="nav search-row" id="top_menu">
          <ul class="nav top-menu">
          </ul>
        </div>
        <div class="top-nav notification-row">
          <ul class="nav pull-right top-menu">
            <nav class="navbar navbar-expand navbar-light bg-transparent topbar mb-4 static-top shadow" style="height: 20px;">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown no-arrow mx-1">
                  <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-bell fa-fw" style="margin-top: 15px;"></i>
                    <!-- Counter - Alerts -->
                    <span class="badge badge-danger badge-counter" style="margin-top: 30px;">3+</span>
                  </a>
                  <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                    <h6 class="dropdown-header">
                      Alerts Center
                    </h6>
                    <a class="dropdown-item d-flex align-items-center" href="#">
                      <div class="mr-3">
                        <div class="icon-circle bg-primary">
                          <i class="fas fa-file-alt text-white"></i>
                        </div>
                      </div>
                      <div>
                        <div class="small text-gray-500">December 12, 2019</div>
                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                      </div>
                    </a>
                    <a class="dropdown-item d-flex align-items-center" href="#">
                      <div class="mr-3">
                        <div class="icon-circle bg-success">
                          <i class="fas fa-donate text-white"></i>
                        </div>
                      </div>
                      <div>
                        <div class="small text-gray-500">December 7, 2019</div>
                        $290.29 has been deposited into your account!
                      </div>
                    </a>
                    <a class="dropdown-item d-flex align-items-center" href="#">
                      <div class="mr-3">
                        <div class="icon-circle bg-warning">
                          <i class="fas fa-exclamation-triangle text-white"></i>
                        </div>
                      </div>
                      <div>
                        <div class="small text-gray-500">December 2, 2019</div>
                        Spending Alert: We've noticed unusually high spending for your account.
                      </div>
                    </a>
                    <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                  </div>
                </li>
               </ul>
              </nav>
              <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                  
                  <?php echo e(Auth::user()->name); ?>

                </a>
                <ul class="dropdown-menu extended logout">
                  <div class="log-arrow-up"></div>
                  <li class="eborder-top">
                    <!--<a href="profile.html">
                      <i class="icon_profile"></i>
                      View Profile
                    </a>-->
                  </li>
                  <li>
                    <a class="" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                      document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                  </li>
                </ul>
            </li>
          
            </ul>
        </div>
      </header>

      <aside>
        <div id="sidebar" class="nav-collapse ">
          <ul class="sidebar-menu">
            <li class="">
              <a class="" href="/home">
                <i class="icon_house_alt"></i>
                <span>Dashboard</span>
              </a>
            </li>
            <li class="sub-menu">
              <a href="/patient" class="active">
                <i class="icon_documents_alt"></i>
                <span>Patient</span>
              </a>
            </li>
            <li class="sub-menu">
              <a href="/patientrecords" class="active">
                <i class="icon_documents_alt"></i>
                <span>Patient's Chart</span>
              </a>
            </li>
             <li class="sub-menu">
              <a href="" class="">
                <i class="icon_documents_alt"></i>
                <span>Sales Records</span>
              </a>
            </li>
          </ul>
        </div>
      </aside>

      </section>
    </section>


    <section id="main-content">
      <section class="wrapper" id="calendarmargin">
        <div class="row">
          <div class="col-md-6 portlets">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h2><strong>APPOINTMENTS</strong></h2>
                <div class="panel-actions">
                  <a href="#" class="wminimize"><i class="fa fa-chevron-up"></i></a>
                  <a href="#" class="wclose"><i class="fa fa-times"></i></a>
                </div>
              </div><br><br><br>
              <div class="panel-body">
                <div id="calendar"></div>
                <br>
                <button id="myBtn">Add Patient Appointment</button>
            </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </section>
    <!-- modal -->
    <div id="myModal" class="modal">
      <div class="col-md-6 portlets">
        <div class="modal-content">
          <div class="pull-left">Add Patient Appointment</div>
          <span class="close">&times;</span>
          <div class="clearfix"></div>
          <div class="padd">
            <div class="form quick-post">

              <form class="form-horizontal">
                <div class="form-group">
                  <label class="control-label col-lg-2" for="title">Name</label>
                  <div class="col-lg-10">
                    <input type="text" class="form-control" id="title">
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-2">Service</label>
                  <div class="col-lg-10">
                    <select class="form-control">
                      <option value="1">Consultation</option>
                      <option value="2">Braces</option>
                      <option value="3">Cleaning</option>
                      <option value="4">Oral Prophylaxis (Light, Moderate,Heavy)</option>
                      <option value="5">Restoration per Surface</option>
                      <option value="6">Temporary Filling</option>
                      <option value="7">Extraction</option>
                      <option value="8">Impaction</option>
                      <option value="9">Root Canal per Treatment (per canal)</option>
                      <option value="10">Porcelain Jacket Crown (per unit)</option>
                      <option value="11">All Porcelain Crown</option>
                      <option value="12">Plastic Complete Denture</option>
                      <option value="13">Porcelain Complete Denture</option>
                      <option value="14">Minimum RPD (1-2)</option>
                      <option value="15">Flexite</option>
                      <option value="16">Orthodontic Treatment (Conventional, Self-ligating)</option>
                      <option value="17">Retainer</option>
                      <option value="18">Rebond</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-2" for="tags">Note</label>
                  <div class="col-lg-10">
                    <input type="text" class="form-control" id="tags">
                  </div>
                </div>
                
                    <fieldset>
                    <div class="form-group">
                  <label class="control-label col-lg-2" for="tags">Date</label>
                  <div class="col-lg-10">
                    <input type="date" class="form-control" id="tags">
                  </div>
                  </div>
                  <fieldset>
                    <div class="form-group">
                  <label class="control-label col-lg-2" for="tags">Time</label>
                  <div class="col-lg-10">
                    <input type="time" class="form-control" id="tags">
                  </div>
                  </div>
                      <!--<div class="form-group">
                        <label for="dtp_input1" class="col-md-2 control-label">Date and Time</label>
                        <div class="input-group date form_datetime col-md-5" data-date="1979-09-16T05:25:07Z" data-date-format="dd MM yyyy - HH:ii p" data-link-field="dtp_input1" style="width: 83%;">
                          <input class="form-control" size="16" type="text" value="" readonly>
                         
                        </div>
                        <input type="hidden" id="dtp_input1" value="" /><br/>
                      </div>-->
                    </fieldset>
                  </form>
                </div>
                <br>
                  <div class="form-group" id="buttons">
                    <div class="col-lg-offset-2 col-lg-9">
                      <button type="submit" class="btn btn-primary">Save</button>
                      <button type="reset" class="btn btn-default">Cancel</button>
                    </div>
                  </div>
         
    <!-- JavaScripts -->
    
    <script type="text/javascript">
      $(function() {
        $(".knob").knob({
          'draw': function() {
            $(this.i).val(this.cv + '%')
          }
        })
      });
      $(document).ready(function() {
        $("#owl-slider").owlCarousel({
          navigation: true,
          slideSpeed: 300,
          paginationSpeed: 400,
          singleItem: true
        });
      });

      $(function() {
        $('select.styled').customSelect();
      });
      
      $(function() {
        $('#map').vectorMap({
          map: 'world_mill_en',
          series: {
            regions: [{
              values: gdpData,
              scale: ['#000', '#000'],
              normalizeFunction: 'polynomial'
            }]
          },
          backgroundColor: '#eef3f7',
          onLabelShow: function(e, el, code) {
            el.html(el.html() + ' (GDP - ' + gdpData[code] + ')');
          }
        });
      });
      var modal = document.getElementById('myModal');
      var btn = document.getElementById("myBtn");
      var span = document.getElementsByClassName("close")[0];
      btn.onclick = function() {
        modal.style.display = "block";
      }
      span.onclick = function() {
        modal.style.display = "none";
      }
      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
        }
      }

      $(document).ready(function() {
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();
        
        var calendar = $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },
          selectable: true,
          selectHelper: true,
          select: function(start, end, allDay) {
            var title = prompt('Event Title:','Name');
            if (title) {
              calendar.fullCalendar('renderEvent',
                {
                  title: title,
                  start: start,
                  end: end,
                  allDay: allDay
                },
                true
              );
            }
            calendar.fullCalendar('unselect');
          },
          editable: true,
          events: [
            {
            },
          ]
        });
      });
      $(function () {
        $('#datetimepicker1').datetimepicker();
      });
        $('.form_datetime').datetimepicker({
            //language:  'fr',
            weekStart: 1,
            todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        forceParse: 0,
            showMeridian: 1
        });
      $('.form_date').datetimepicker({
            language:  'fr',
            weekStart: 1,
            todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        minView: 2,
        forceParse: 0
        });
      $('.form_time').datetimepicker({
            language:  'fr',
            weekStart: 1,
            todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 1,
        minView: 0,
        maxView: 1,
        forceParse: 0
        });
    </script>
    <script src="assets/fullcalendar/fullcalendar/fullcalendar.js"></script>
    <script src="js/calendar-custom.js"></script>
  </body>
</html>