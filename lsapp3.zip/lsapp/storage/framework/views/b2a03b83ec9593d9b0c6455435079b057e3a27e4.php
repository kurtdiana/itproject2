<?php /* C:\xampp\htdocs\lsapp\resources\views/layouts/index.blade.php */ ?>
<html>
    <head>
        <title>KURT DIANA</title>
    </head>
    <body>
        <center><font size="30"><b><p>HELLO HELLO</p></b></font></center>
        <a href='/gago'><center><font size="20"><b><p>PINDUTIN MO TO</p></b></font></center></a>
    </body>
    <script>
        alert('HELLO POGI');
    </script>
</html>