<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Perez - Magabo Dental Clinic - Dashboard</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- CSS -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
    <!-- scripts -->
    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui-1.10.4.min.js"></script>
    <script src="js/jquery-1.8.3.min.js"></script>
    <script  src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js"> </script>
    <script src="js/scripts.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/demo/datatables-demo.js"></script>
  </head>
  <body id="page-top">
    @if (session('status'))
            {{ session('status') }}
    @endif
    @guest
        <li class="navbar-item">
            <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
        </li>
        @if (Route::has('register'))
            <li class="navbar-item">
                <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
            </li>
        @endif
    @else
    <div id="wrapper">
    <section id="container" class="">
    <header class="header dark-bg">
        <div class="toggle-nav">
          <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
        </div>
        <a href="/home" class="logo">PEREZ-MAGABO <span class="lite">CLINIC </span></a>
        <div class="nav search-row" id="top_menu">
          <ul class="nav top-menu">
          </ul>
        </div>
        <div class="top-nav notification-row">
          <ul class="nav pull-right top-menu">
            <nav class="navbar navbar-expand navbar-light bg-transparent topbar mb-4 static-top shadow" style="height: 20px;">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown no-arrow mx-1">
                  <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-bell fa-fw" style="margin-top: 15px;"></i>
                    <!-- Counter - Alerts -->
                    <span class="badge badge-danger badge-counter" style="margin-top: 30px;">3+</span>
                  </a>
                  <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                    <h6 class="dropdown-header">
                      Alerts Center
                    </h6>
                    <a class="dropdown-item d-flex align-items-center" href="#">
                      <div class="mr-3">
                        <div class="icon-circle bg-primary">
                          <i class="fas fa-file-alt text-white"></i>
                        </div>
                      </div>
                      <div>
                        <div class="small text-gray-500">December 12, 2019</div>
                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                      </div>
                    </a>
                    <a class="dropdown-item d-flex align-items-center" href="#">
                      <div class="mr-3">
                        <div class="icon-circle bg-success">
                          <i class="fas fa-donate text-white"></i>
                        </div>
                      </div>
                      <div>
                        <div class="small text-gray-500">December 7, 2019</div>
                        $290.29 has been deposited into your account!
                      </div>
                    </a>
                    <a class="dropdown-item d-flex align-items-center" href="#">
                      <div class="mr-3">
                        <div class="icon-circle bg-warning">
                          <i class="fas fa-exclamation-triangle text-white"></i>
                        </div>
                      </div>
                      <div>
                        <div class="small text-gray-500">December 2, 2019</div>
                        Spending Alert: We've noticed unusually high spending for your account.
                      </div>
                    </a>
                    <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                  </div>
                </li>
               </ul>
              </nav>
              <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                  <span class="profile-ava">
                    <img alt="" src="img/avatar1_small.jpg">
                  </span>
                  {{ Auth::user()->name }}
                </a>
                <ul class="dropdown-menu extended logout">
                  <div class="log-arrow-up"></div>
                  
                  <li>
                    <a class="" href="{{ route('logout') }}"
                        onclick="event.preventDefault();
                                      document.getElementById('logout-form').submit();">
                        {{ __('Logout') }}
                    </a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                  </li>
                </ul>
            </li>
          
            </ul>
        </div>
      </header>


      <aside>
        <div id="sidebar" class="nav-collapse ">
          <ul class="sidebar-menu">
            <li class="">
              <a class="" href="/home">
                <i class="icon_house_alt"></i>
                <span>Dashboard</span>
              </a>
            </li>
            <li class="sub-menu">
              <a href="/patient" class="active">
                <i class="icon_documents_alt"></i>
                <span>Patient</span>
              </a>
            </li>
            <li class="sub-menu">
              <a href="" class="">
                <i class="icon_documents_alt"></i>
                <span>Patient's Chart</span>
              </a>
            </li>
             <li class="sub-menu">
              <a href="" class="">
                <i class="icon_documents_alt"></i>
                <span>Sales Records</span>
              </a>
            </li>
          </ul>
        </div>
      </aside>
      <section id="main-content">
      <section class="wrapper">
      <div class="nav search-row" id="top_menu">
        <ul class="nav top-menu">
          
        </ul>
      </div>
<br>
<br>
                </li>
              </ul>
            </nav>
            <center>
          <div class="container-fluid">
              <h1 class="h3 mb-1 text-gray-800">Add New Patient</h1>
              
                  <div class="card shadow mb-4 col-md-6">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Please enter the needed information of the patient.</h6>
                    </div>
                    <div class="card-body">
                      @if($errors->any())
                      <div class="alert alert-danger">
                        <ul>
                          @foreach ($errors->all() as $error)
                            <li>{{$error}}</li>
                              @endforeach
                        </ul>
                      </div>
                      @endif
                      <div class="flash-message">
                        @foreach (['danger', 'warning', 'success', 'info'] as $msg)
                          @if(Session::has('alert-' . $msg))
                            <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}</p>
                           @endif
                         @endforeach
                      </div>
                      <form action="/addpatient" method="POST">
                        @csrf
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-12">
                                    <input type="text" onkeypress='validateName(event)' class="form-control form-control-user" id="exampleFirstName" placeholder="First Name" name="first_name" required>
                                    <br>
                                    <input type="text" onkeypress='validateName(event)' class="form-control form-control-user" id="exampleLastName" placeholder="Last Name" name='last_name' required>
                                    <br>
                                    <select class="form-control" name='civilstats' required>
                                        <option value='Single'>Single</option>
                                        <option value='Married'>Married</option>
                                        <option value='Widow'>Widow</option>
                                    </select>
                                    <br>
                                    <select class="form-control" name='sex' required>      
                                        <option value='Male'>Male</option>
                                        <option value='Female'>Female</option>
                                    </select>
                                    <br>
                                    <input type="text" class="form-control form-control-user" id="exampleAddress" placeholder="Present Address" name='pat_address' required>
                                    <br>
                                    <input type="text" class="form-control form-control-user" id="exampleAddress" placeholder="Permanent Address" name='pat_paddress' required>
                                    <br>
                                    <input onfocus="(this.type='date')" class="form-control form-control-user" id="exampleBirthday" placeholder="Birthday" name='birthday' required>
                                    <br>
                                    <input type="text" onkeypress='validate(event)' class="form-control form-control-user" id="exampleContactNo" placeholder="Contact No." name='pat_contno' required>
                                    <br>
                                    <input type="text" class="form-control form-control-user" id="exampleMedical" placeholder="Case History" name='case_history' required>
                                    <br>
                                    <center>
                                      <button class="btn btn-success " type='submit'>
                                        Save
                                      </button>
                                    </center>
                                </div>
                            </div>
                        </div>
                      </form>
                    </div>
                </div>
          </div>       
          </center>
    <a class="scroll-to-top rounded" href="#page-top">  
      <i class="fas fa-angle-up"></i>
    </a>
    <!-- scripts -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script>
      function validate(evt) {
  var theEvent = evt || window.event;

  // Handle paste
  if (theEvent.type === 'paste') {
      key = event.clipboardData.getData('text/plain');
  } else {
  // Handle key press
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
  }
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}

function validateName(evt) {
  var theEvent = evt || window.event;

  // Handle paste
  if (theEvent.type === 'paste') {
      key = event.clipboardData.getData('text/plain');
  } else {
  // Handle key press
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
  }
  var regex = /[A-Z,a-z]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}

    </script>
  </body>
  @endguest
</html>