<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMedtreTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('medtre', function (Blueprint $table) {
            $table->integer('med_recordID')->unsigned();
            $table->integer('treatmentID')->unsigned();
            $table->string('treat_description');
            $table->foreign('med_recordID')
            ->references('med_recordID')
            ->on('medical record')
            ->onDelete('cascade');
            $table->foreign('treatmentID')
            ->references('treatmentID')
            ->on('treatment')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('medtre');
    }
}
