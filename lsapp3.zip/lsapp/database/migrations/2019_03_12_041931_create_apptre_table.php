<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateApptreTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('apptre', function (Blueprint $table) {
            $table->integer('appointmentID')->unsigned();
            $table->integer('treatmentID')->unsigned();
            $table->double('treatCost');
            $table->time('appointmentTime');
            $table->foreign('appointmentID')
            ->references('appointmentID')
            ->on('appointment')
            ->onDelete('cascade');
            $table->foreign('treatmentID')
            ->references('treatmentID')
            ->on('treatment')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('apptre');
    }
}
